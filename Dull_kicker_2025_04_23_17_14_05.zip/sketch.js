var Num = 0;
var ParticleArray = Array(Num);
var OscillatorArray = Array(Num);
function setup() {
  createCanvas(windowWidth, windowHeight);
  Num = (width * height) / 1300;

  background(0);
  noStroke();
  setParticles();
  setOscillator()
  for (let p of OscillatorArray){
    p.start()
  }
}

function draw() {
  frameRate(60);
  blendMode(ADD);
  if (mouseIsPressed) {
    loadPixels();

    for (let p of ParticleArray) {
      p.update();
      // p.update();
      // p.wrap();
      // p.display();
    }

    updatePixels();
  }

  if (keyIsPressed) {
    setParticles();
    for (i = 0; i < width; i++) {
      for (h = 0; h < height; h++) set(i, h, color(0, 0, 0));
      updatePixels();
    }
    h = 0;
  }
}

function setParticles() {
  for (let i = 0; i < Num; i++) {
    ParticleArray[i] = new Particle();
  }
}

function setOscillator(){
  for(let i = 0; i<Num; i++){
    OscillatorArray[i] = new Oscillator()
  }
}

class Particle {
  constructor() {
    this.posX = random(width);
    this.posY = random(height);

    this.r = random(0, 30);
    this.g = random(0, 30);
    this.b = random(100, 240);
    this.c = color(this.r, this.g, this.b);
    this.incr = 0.000128;
    this.theta;
    this.moveX;
    this.moveY;
    this.dis;
    this.dice;
  }
  update() {
    this.incr += 0.00000128;
    this.dice = int(random(1, 100));
    this.theta = (noise(this.posX, this.posY, this.incr) - 0.5) * TWO_PI;
    this.moveX = (mouseX - this.posX) / 130;
    this.moveY = (mouseY - this.posY) / 130;
    this.dis = sqrt(sq(this.posX - mouseX) + sq(this.posY - mouseY));
    if (this.dis > (width + height) / 4) {
      if (this.b < 255) {
        this.b += this.dis / ((width + height) / 15);
      }
      if (this.r > 0) {
        this.r += -this.dis / ((width + height) / 15);
      }
    }
    if (this.dis < (width + height) / 4) {
      if (this.r < 255) {
        this.r += (width + height) / (this.dis * 15);
      }
      if (this.b > 0) {
        this.b -= (width + height) / (this.dis * 15);
      }
    }
    //console.log((sin(this.theta) + cos(this.theta)))
    this.posX +=
      this.moveX +
      tan(this.theta) * this.dis * this.dis * this.moveY * 0.0001 +
      random(-0.1, 0.1) * PI;// 
    this.posY +=
      this.moveY +
      tan(this.theta) * this.dis * this.dis * this.moveX * 0.0001+
      random(-0.1, 0.1) * PI;// 
    if (this.dice == 1) {
      this.c = color(random(180, 250));
    } else {
      this.c = color(this.r, this.g, this.b);
    }
    set(this.posX, this.posY, this.c);
    if (this.posX > width) {
      this.posX = 0;
    }
    if (this.posY > height) {
      this.posY = 0;
    }
  }
}

class Oscillator {
  constructor() {
  this.osc = new p5.Oscillator("sine")
   
  }
    start() { 
}
}